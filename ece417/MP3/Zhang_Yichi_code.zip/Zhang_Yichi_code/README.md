This is the readme file for ECE417 MP2
Author:  Yichi Zhang

In this MO, we basically use CNN model to train and test the input file. 
The MP3.ipynb is the jupyter noyebook.

To run the code, just simply run all the sections and the final result will be printed
on screen. The training process lasts for approximate 10 minutes and the data augmentation lasts for approximate 10 minutes
