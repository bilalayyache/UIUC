This is the readme file for ECE417 MP2
Author: Yichi Zhang

In this MP, we basically use the HMM model to train and test the input file.
The MP2.ipynb is the jupyter notebook contains most of the code for this MP.

To run the code, just simply run all the sections and the final result will be printed
on screen. The whole process lasts for approximate 7 minutes.

There are one more folder named "dd" in the zip file. This is the user recorded sound.
We recored each word five times and therefore there are total 25 wav files.
Also, there are two matlab source code inside this folder. One is record_user.m and user_fea_write.m. record_user.m is the file that we record our sound and user_fea_write.m is the file that we take the input wav files and generate the mfcc features and write fea files for python code to read.
