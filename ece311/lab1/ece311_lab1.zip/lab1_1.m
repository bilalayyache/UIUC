%% 1. Equispace point
a = 0;
b = 1;
N = 12;
vector_1 = linspace(a, b, N);