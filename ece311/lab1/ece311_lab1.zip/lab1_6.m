clear all
close all
clc

load speechsig.mat
soundsc(x, 7500)